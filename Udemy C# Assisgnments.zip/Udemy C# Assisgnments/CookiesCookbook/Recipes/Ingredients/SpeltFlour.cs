﻿namespace CookieCookbook.Recipes.Ingredients;

public class SpeltFlour : Flour
{
    public override int Id => 2;
    public override string Name => "Spelt flour";
}

