﻿namespace Game
{
    public enum GameResult
    {
        Victory,
        Loss
    }
}
