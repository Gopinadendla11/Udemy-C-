﻿namespace Game;

public interface IDice
{
    int Roll();
}