﻿namespace GameDataParser.DataAccess;

public interface IFileReader
{
    string Read(string fileName);
}