﻿public interface IRandom
{
    int Next(int minValue, int maxValue);
    int Next(int maxValue);
}
